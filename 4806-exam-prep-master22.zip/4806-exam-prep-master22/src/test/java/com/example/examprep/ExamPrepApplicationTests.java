package com.example.examprep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamPrepApplicationTests {

    @Test
    void contextLoads() {
    }

}
